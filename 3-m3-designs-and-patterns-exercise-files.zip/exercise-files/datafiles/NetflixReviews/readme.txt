This is a scaled-down version (120MB) of the original Netflix datafile.
The original netflix data file (2GB) is available here:

  http://bit.ly/nflx-2gb

